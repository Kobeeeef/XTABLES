package org.kobe.xbot.Utilities;

public enum XTableStatus {
    ONLINE,
    OFFLINE,
    CLEANING,
    REBOOTING,
    STARTING
}
