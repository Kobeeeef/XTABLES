package org.kobe.xbot.Utilities;

public enum ResponseStatus {
    OK,
    FAIL
}
